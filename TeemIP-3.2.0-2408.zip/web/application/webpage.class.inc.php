<?php
/**
 * @deprecated  3.0.0 will be removed in 3.1.0 - moved to sources/Application/WebPage/WebPage.php, now loadable using autoloader
 * @license     http://opensource.org/licenses/AGPL-3.0
 * @copyright   Copyright (C) 2010-2024 Combodo SAS
 */

DeprecatedCallsLog::NotifyDeprecatedFile('moved to sources/Application/WebPage/WebPage.php, now loadable using autoloader');