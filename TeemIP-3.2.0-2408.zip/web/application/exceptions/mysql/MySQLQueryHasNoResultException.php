<?php
/*
 * @copyright   Copyright (C) 2010-2024 Combodo SAS
 * @license     http://opensource.org/licenses/AGPL-3.0
 */

/**
 * Class MySQLQueryHasNoResultException
 *
 * @since 2.5.0
 */
class MySQLQueryHasNoResultException extends MySQLException
{

}